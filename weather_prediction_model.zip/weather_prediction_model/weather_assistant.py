from datetime import datetime, timedelta
import pandas as pd
import re

# Dictionary of common phrases in different languages
TRANSLATIONS = {
    'tomorrow': ['कल', 'उद्या', 'kal', 'udya'],
    'today': ['आज', 'aaj'],
    'weather': ['मौसम', 'हवामान', 'mausam', 'hawaman'],
    'temperature': ['तापमान', 'tapman'],
    'rain': ['बारिश', 'पाऊस', 'barish', 'paus'],
    'wind': ['हवा', 'वारा', 'hawa', 'vara']
}

# Load our weather prediction components
import joblib
from combined_forecast import OpenWeatherAPI
from weather_model_enhanced import forecast_next_7_days

def combine_forecasts(model_forecast, api_forecast):
    """
    Combine forecasts from our model and OpenWeather API
    using weighted averaging based on each model's historical performance
    """
    # Weights based on R² scores (can be adjusted)
    weights = {
        'temp': {'model': 0.6, 'api': 0.4},  # Our model is very good with temperature
        'rain': {'model': 0.3, 'api': 0.7},  # API might be better with precipitation
        'wind': {'model': 0.5, 'api': 0.5}   # Equal weights for wind
    }
    
    combined = []
    for i in range(min(len(model_forecast), len(api_forecast))):
        model_day = model_forecast[i]
        api_day = api_forecast.iloc[i]
        
        # Combine predictions using weights
        temp = (weights['temp']['model'] * model_day['temp'] +
                weights['temp']['api'] * api_day['temp'])
        rain = (weights['rain']['model'] * model_day['prcp'] +
                weights['rain']['api'] * api_day['rain'])
        wind = (weights['wind']['model'] * model_day['wspd'] +
                weights['wind']['api'] * api_day['wind'])
        
        combined.append({
            'date': api_day['date'],
            'temperature': round(temp, 1),
            'rainfall': round(rain, 1),
            'wind_speed': round(wind, 1)
        })
    
    return combined

def parse_query(query):
    """Parse the query to understand what weather info is requested"""
    query = query.lower()
    
    # Parse date
    date = None
    if any(word in query for word in TRANSLATIONS['tomorrow']):
        date = datetime.now().date() + timedelta(days=1)
    elif any(word in query for word in TRANSLATIONS['today']):
        date = datetime.now().date()
    else:
        # Try to find a date in format "dd/mm" or "dd-mm" or "dd mm"
        date_patterns = [
            r'(\d{1,2})[\/-](\d{1,2})',  # dd/mm or dd-mm
            r'(\d{1,2})\s+(?:nov|november)',  # dd nov
            r'(\d{1,2})(?:th|rd|nd|st)?\s+(?:nov|november)'  # dd(th) nov
        ]
        for pattern in date_patterns:
            match = re.search(pattern, query)
            if match:
                try:
                    day = int(match.group(1))
                    date = datetime(2025, 11, day).date()
                    break
                except ValueError:
                    continue
    
    # Parse info type
    info_type = 'all'
    if any(word in query for word in TRANSLATIONS['temperature']):
        info_type = 'temperature'
    elif any(word in query for word in TRANSLATIONS['rain']):
        info_type = 'rain'
    elif any(word in query for word in TRANSLATIONS['wind']):
        info_type = 'wind'
    
    return {
        'date': date or datetime.now().date(),
        'info_type': info_type
    }

def format_weather_response(weather_data, query_info):
    """Format weather data into a natural language response"""
    date_str = weather_data['date'].strftime('%Y-%m-%d')
    temp = weather_data['temperature']
    rain = weather_data['rainfall']
    wind = weather_data['wind_speed']
    
    # Format based on info type
    if query_info['info_type'] == 'temperature':
        response = (
            f"🌡️ Temperature on {date_str}: {temp}°C\n"
            f"{'🌞 Pleasant day!' if 20 <= temp <= 28 else '🔥 Quite warm!' if temp > 28 else '❄️ Bit cool!'}"
        )
    elif query_info['info_type'] == 'rain':
        response = (
            f"🌧️ Rainfall expected on {date_str}: {rain}mm\n"
            f"{'☔ Carry an umbrella!' if rain > 2 else '🌂 Light rain possible.' if rain > 0 else '☀️ No rain expected.'}"
        )
    elif query_info['info_type'] == 'wind':
        response = (
            f"💨 Wind speed on {date_str}: {wind} km/h\n"
            f"{'🌪️ Windy conditions!' if wind > 20 else '🍃 Gentle breeze.' if wind > 10 else '😊 Calm weather.'}"
        )
    else:
        response = (
            f"Weather Forecast for Pune - {date_str}:\n"
            f"🌡️ Temperature: {temp}°C\n"
            f"🌧️ Rainfall: {rain}mm\n"
            f"💨 Wind Speed: {wind} km/h\n\n"
            f"Summary: "
            f"{'🌞' if temp > 25 else '⛅'} "
            f"{'☔' if rain > 2 else '🌂' if rain > 0 else '☀️'} "
            f"{'🌪️' if wind > 20 else '🍃'}"
        )
    
    return response

def get_weather_forecast(query):
    """Main function to handle weather queries"""
    # Parse the query
    query_info = parse_query(query)
    
    # Initialize API and get forecasts
    api_key = "c07041ef55c7d3a3bb10f589abd00f6e"
    weather_api = OpenWeatherAPI(api_key)
    
    # Pune coordinates
    LAT = 18.5204
    LON = 73.8567
    
    # Get current date and check if we need to update our model
    current_date = datetime.now()
    try:
        with open('last_update.txt', 'r') as f:
            last_update = datetime.strptime(f.read().strip(), '%Y-%m-%d')
        days_since_update = (current_date.date() - last_update.date()).days
    except:
        days_since_update = float('inf')
    
    # If data is more than 7 days old, notify user
    if days_since_update > 7:
        print("\nNote: Weather data needs updating. Predictions may be less accurate.")
    
    # Get both forecasts
    api_forecast = weather_api.get_forecast(LAT, LON)
    model_forecast = forecast_next_7_days(current_date)
    
    # Combine forecasts
    combined_forecast = combine_forecasts(model_forecast, api_forecast)
    
    # Get forecast for requested date
    target_date = query_info['date']
    
    forecast = None
    for day in combined_forecast:
        if isinstance(day['date'], datetime):
            compare_date = day['date'].date()
        else:
            compare_date = day['date']
            
        if compare_date == target_date:
            forecast = day
            break
    
    if not forecast:
        return "मैं केवल अगले 5-7 दिनों का मौसम बता सकता हूं। (I can only provide forecasts for the next 5-7 days.)"
    
    # Format response in natural language
    response = format_weather_response(forecast, query_info)
    return response

def main():
    print("पुणे का मौसम जानने के लिए स्वागत है! (Welcome to Pune Weather Assistant!)")
    print("आप किसी भी भाषा में पूछ सकते हैं। (You can ask in any language.)")
    print("To exit, type 'quit' or 'exit'\n")
    
    while True:
        query = input("\nआपका प्रश्न (Your question): ").strip()
        
        if query.lower() in ['quit', 'exit', 'बंद', 'बाहर']:
            print("धन्यवाद! अलविदा! (Thank you! Goodbye!)")
            break
            
        try:
            response = get_weather_forecast(query)
            print("\n" + response + "\n")
            print("-" * 50)
        except Exception as e:
            print(f"\nSorry, there was an error: {str(e)}")
            print("Please try again with a different question.")

if __name__ == "__main__":
    main()