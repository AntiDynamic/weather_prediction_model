import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import plotly.graph_objects as go
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

class WeatherPredictor:
    def __init__(self):
        self.models = {
            'Temperature (°C)': None,
            'Precipitation (mm)': None,
            'Wind Speed (km/h)': None
        }
        self.features = []

    def prepare_data(self):
        # Load daily data
        print("Loading data...")
        data = pd.read_csv('pune_weather_cleaned.csv', parse_dates=['time'])
        print(f"Initial data shape: {data.shape}")
        
        # Handle missing values in required columns first
        required_cols = ['tavg', 'prcp', 'wspd']
        data[required_cols] = data[required_cols].fillna(method='ffill').fillna(method='bfill')
        
        # Create basic features
        data['month_sin'] = np.sin(2 * np.pi * data['month']/12)
        data['month_cos'] = np.cos(2 * np.pi * data['month']/12)
        
        # Create lag features
        for col in ['tavg', 'prcp']:
            data[f'{col}_lag1'] = data[col].shift(1)
            data[f'{col}_lag3'] = data[col].shift(3)
        
        # Fill missing values in lag features
        lag_cols = ['tavg_lag1', 'tavg_lag3', 'prcp_lag1', 'prcp_lag3']
        data[lag_cols] = data[lag_cols].fillna(method='ffill').fillna(method='bfill')
        
        # Select features
        self.features = ['month_sin', 'month_cos', 
                        'tavg_lag1', 'tavg_lag3', 'prcp_lag1', 'prcp_lag3',
                        'year', 'month', 'dayofyear']
        
        # Remove any remaining rows with NaN values
        data = data.dropna(subset=required_cols + self.features)
        print(f"Final data shape: {data.shape}")
        
        self.data = data
        return data

    def train_models(self):
        # Split into train and test
        train_data = self.data[:-30]  # Keep last 30 days for testing
        test_data = self.data[-30:]
        
        # Train models for each target
        targets = {
            'Temperature (°C)': 'tavg',
            'Precipitation (mm)': 'prcp',
            'Wind Speed (km/h)': 'wspd'
        }
        
        results = {}
        for name, target in targets.items():
            print(f"\nTraining {name} model...")
            # Prepare data
            X = train_data[self.features]
            y = train_data[target]
            
            # Train Random Forest model
            model = RandomForestRegressor(
                n_estimators=100,
                max_depth=10,
                random_state=42
            )
            model.fit(X, y)
            self.models[name] = model
            
            # Evaluate
            X_test = test_data[self.features]
            y_test = test_data[target]
            y_pred = model.predict(X_test)
            
            results[name] = {
                'MAE': mean_absolute_error(y_test, y_pred),
                'RMSE': np.sqrt(mean_squared_error(y_test, y_pred)),
                'R2': r2_score(y_test, y_pred)
            }
        
        return results

    def predict_next_7_days(self):
        # Get last available data
        last_data = self.data.iloc[-1:].copy()
        
        predictions = {
            'dates': [(datetime.now() + timedelta(days=i)).date() for i in range(1, 8)],
        }
        
        # Make predictions for next 7 days
        current_features = last_data[self.features].values
        
        for name, model in self.models.items():
            predictions[name] = []
            for i in range(7):
                pred = model.predict(current_features)[0]
                predictions[name].append(pred)
                
                # Update features for next prediction
                if i > 0:
                    feature_idx = self.features.index('tavg_lag1')
                    current_features[0, feature_idx] = pred
                    if i > 2:
                        feature_idx = self.features.index('tavg_lag3')
                        current_features[0, feature_idx] = predictions[name][i-3]
        
        return predictions

    def plot_predictions(self, predictions):
        # Create interactive plot
        fig = go.Figure()
        
        for var_name in self.models.keys():
            fig.add_trace(go.Scatter(
                x=predictions['dates'],
                y=predictions[var_name],
                name=var_name,
                mode='lines+markers'
            ))
        
        fig.update_layout(
            title='7-Day Weather Forecast',
            xaxis_title='Date',
            yaxis_title='Value',
            legend_title='Variables'
        )
        fig.show()

if __name__ == "__main__":
    print("Initializing weather prediction model...")
    predictor = WeatherPredictor()
    
    print("Preparing data...")
    data = predictor.prepare_data()
    
    print("\nTraining models...")
    evaluation = predictor.train_models()
    
    print("\nModel Evaluation Metrics:")
    for target, metrics in evaluation.items():
        print(f"\n{target}:")
        for metric_name, value in metrics.items():
            print(f"{metric_name}: {value:.4f}")
    
    print("\nGenerating 7-day forecast...")
    predictions = predictor.predict_next_7_days()
    predictor.plot_predictions(predictions)