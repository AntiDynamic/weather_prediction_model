import requests
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import joblib

class OpenWeatherAPI:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://api.openweathermap.org/data/2.5"
        
    def get_forecast(self, lat, lon):
        """Get 5-day forecast from OpenWeather API"""
        endpoint = f"{self.base_url}/forecast"
        params = {
            "lat": lat,
            "lon": lon,
            "appid": self.api_key,
            "units": "metric",  # Use Celsius
        }
        
        try:
            response = requests.get(endpoint, params=params)
            if response.status_code == 401:
                print("API Key error. Please verify your OpenWeather API key.")
                return None
            response.raise_for_status()
            data = response.json()
            
            # Process forecast data
            forecasts = []
            for item in data['list']:
                dt = datetime.fromtimestamp(item['dt'])
                temp = item['main']['temp']
                rain = item.get('rain', {}).get('3h', 0)  # Rain in mm for 3 hours
                wind = item['wind']['speed'] * 3.6  # Convert m/s to km/h
                
                forecasts.append({
                    'date': dt.date(),
                    'temp': temp,
                    'rain': rain,
                    'wind': wind
                })
            
            # Group by date and calculate daily averages
            df = pd.DataFrame(forecasts)
            daily = df.groupby('date').agg({
                'temp': 'mean',
                'rain': 'sum',
                'wind': 'mean'
            }).reset_index()
            
            return daily
            
        except requests.exceptions.RequestException as e:
            print(f"Error fetching OpenWeather data: {e}")
            return None

def load_enhanced_model():
    """Load our trained enhanced model"""
    try:
        model_data = joblib.load('weather_model_enhanced.pkl')
        return model_data
    except Exception as e:
        print(f"Error loading enhanced model: {e}")
        return None

def combine_forecasts(model_forecast, api_forecast):
    """
    Combine forecasts from our model and OpenWeather API
    using weighted averaging based on each model's historical performance
    """
    # Weights based on R² scores (can be adjusted)
    weights = {
        'temp': {'model': 0.6, 'api': 0.4},  # Our model is very good with temperature
        'rain': {'model': 0.3, 'api': 0.7},  # API might be better with precipitation
        'wind': {'model': 0.5, 'api': 0.5}   # Equal weights for wind
    }
    
    combined = []
    for i in range(min(len(model_forecast), len(api_forecast))):
        model_day = model_forecast[i]
        api_day = api_forecast.iloc[i]
        
        # Combine predictions using weights
        temp = (weights['temp']['model'] * model_day['temp'] +
                weights['temp']['api'] * api_day['temp'])
        rain = (weights['rain']['model'] * model_day['prcp'] +
                weights['rain']['api'] * api_day['rain'])
        wind = (weights['wind']['model'] * model_day['wspd'] +
                weights['wind']['api'] * api_day['wind'])
        
        combined.append({
            'date': api_day['date'],
            'temperature': round(temp, 1),
            'rainfall': round(rain, 1),
            'wind_speed': round(wind, 1)
        })
    
    return combined

def main():
    # Initialize OpenWeather API
    API_KEY = "c07041ef55c7d3a3bb10f589abd00f6e"
    weather_api = OpenWeatherAPI(API_KEY)
    
    # Pune coordinates
    LAT = 18.5204
    LON = 73.8567
    
    print("Fetching OpenWeather API forecast...")
    api_forecast = weather_api.get_forecast(LAT, LON)
    
    if api_forecast is None:
        print("Failed to get OpenWeather forecast!")
        return
    
    print("\nRunning enhanced model forecast...")
    # Get our model's forecast
    from weather_model_enhanced import forecast_next_7_days
    model_forecast = forecast_next_7_days(datetime.now())
    
    print("\nCombining forecasts...")
    combined_forecast = combine_forecasts(model_forecast, api_forecast)
    
    # Display results
    print("\nCombined 7-Day Weather Forecast for Pune:")
    print("========================================")
    for day in combined_forecast:
        date_str = day['date'].strftime('%Y-%m-%d')
        print(f"{date_str}:")
        print(f"  Temperature: {day['temperature']}°C")
        print(f"  Rainfall  : {day['rainfall']}mm")
        print(f"  Wind Speed: {day['wind_speed']} km/h")
        print("----------------------------------------")

if __name__ == "__main__":
    main()